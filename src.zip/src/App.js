import logo from './logo.svg';
import './App.css';
import LoginPage from './components/LoginPage';

function App() {
  return (
   <>
   <LoginPage/>
   </>
  );
}

export default App;
